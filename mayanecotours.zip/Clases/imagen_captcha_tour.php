<?php
include_once('Captcha_tour.php');
$captcha = new Captcha_tour();
$captcha->genera_imagen();
//$captcha->valida_captcha();
?>