<?php
include_once('Captcha.php');
$captcha = new Captcha();
$captcha->genera_imagen();
//$captcha->valida_captcha();
?>