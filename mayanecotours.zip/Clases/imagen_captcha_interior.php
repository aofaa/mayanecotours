<?php
include_once('Captcha_interior.php');
$captcha = new Captcha_interior();
$captcha->genera_imagen();
//$captcha->valida_captcha();
?>