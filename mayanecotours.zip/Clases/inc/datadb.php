<?php
/*return array(
    'host' => 'localhost',
    'username' => 'posgrad3_oferta',
    'pass' => 'oferta_2015',
    'db' => 'posgrad3_oferta_2015'
);*/

return array(
    'host' => '127.0.0.1',
    'username' => 'root',
    'pass' => '',
    'db' => 'mayanecotours'
);

?>