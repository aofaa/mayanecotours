<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
        <h4 class="modal-title">¡RESERVA AHORA!</h4>
      </div>
      <div class="modal-body">
        <div align="center">
          <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
            <input type="hidden" name="cmd" value="_s-xclick">
            <input type="hidden" name="hosted_button_id" value="4FBWNLR8SKWHC">
            
            <div class="titulo-tour">
            <input type="hidden" name="on0" value="Tour Deposit">Tour Deposit
            </div>
            
            <div>
            <select name="os0">
               <option value="1 Pax">1 Pax $125.00 MXN</option>
               <option value="2 Pax">2 Pax $250.00 MXN</option>
               <option value="3 Pax">3 Pax $375.00 MXN</option>
               <option value="4 Pax">4 Pax $500.00 MXN</option>
               <option value="5 Pax">5 Pax $625.00 MXN</option>
               <option value="6 Pax">6 Pax $750.00 MXN</option>
               <option value="7 Pax">7 Pax $875.00 MXN</option>
               <option value="8 Pax">8 Pax $1,000.00 MXN</option>
               <option value="9 Pax">9 Pax $1,125.00 MXN</option>
               <option value="10 Pax">10 Pax $1,250.00 MXN</option>
            </select> 
            </div>
            <input type="hidden" name="currency_code" value="MXN">
            <input type="image" src="https://www.paypalobjects.com/en_US/MX/i/btn/btn_paynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
            <img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
          </form> 
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
      </div>
    </div>

  </div>
</div>